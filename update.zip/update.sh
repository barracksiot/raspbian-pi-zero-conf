sudo apt-get -y install nginx
unzip t-rex-runner-gh-pages.zip
sudo cp -R t-rex-runner-gh-pages/* /var/www/html/
sudo rm -f /var/www/html/index.nginx-debian.html
sudo /etc/init.d/nginx start